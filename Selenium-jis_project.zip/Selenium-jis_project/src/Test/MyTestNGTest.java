package Test;

import Hooks.BaseTest;

public class MyTestNGTest extends BaseTest {

/*
    public void validatingTheIDs_AreDifferentAfterClickingRedButton() {
        DashboardPage challangingDOM = new DashboardPage(driver);
        challangingDOM.navigateTo("https://the-internet.herokuapp.com/");
        challangingDOM.clickChallangingDOM();
        Assert.assertFalse(challangingDOM.validatingIdsShouldNotBeSameAfterClickingRedBtn(), "Ids are same after clicking on red button");

    }
*/

    public void validateHelloWorld() {
     //   HomePage dynamicLoading = new HomePage(driver);
      //  dynamicLoading.navigateTo("file:///C:/Users/ritur/IdeaProjects/Selenium/registration-test/registration-test/index.html");
  //      Assert.assertEquals(dynamicLoading.validateHelloButton(),"Registration Test");

    }
}



